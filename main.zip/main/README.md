Hardware Control \& Monitoring Dashboard



A professional, Flask-based web interface designed for real-time monitoring and control of hardware devices via REST API. This dashboard provides a clean, "Expert View" for technical users to manage device attributes, track historical data, and export system states.

🚀 Key Features



&nbsp;   Real-time Monitoring: Live updates of device attributes with a single click.



&nbsp;   Expert Modal: Detailed technical view for every parameter, including Modbus registers, data types, and valid ranges.



&nbsp;   Hardware Control: Seamlessly update writable attributes directly from the UI with built-in range validation.



&nbsp;   Historical Trends: Integrated line charts (Chart.js) showing data fluctuations over the last 24 hours.



&nbsp;   Excel Export: One-click generation of system-wide data reports.



&nbsp;   Smart Filtering: "iOS-style" toggle to quickly isolate editable attributes.



&nbsp;   Background Logging: Automatic data logging to a local SQLite database every 3 minutes.



🛠 Prerequisites



Before running the script, ensure you have Python 3.8+ installed on your system.

Required Libraries



You need to install the following dependencies:

Bash



pip install flask flask-apscheduler requests pandas openpyxl



&nbsp;   flask: The web framework.



&nbsp;   flask-apscheduler: Handles background data logging tasks.



&nbsp;   requests: Manages communication with the hardware API.



&nbsp;   pandas \& openpyxl: Required for generating Excel reports.



⚙️ Configuration



Before launching, update the config.json file with your device's details:

JSON



{

&nbsp;   "api\_url": "https://your-device-ip:8443/api/v1/...",

&nbsp;   "username": "your\_username",

&nbsp;   "password": "your\_password"

}



🏃 How to Run



&nbsp;   Initialize Database: The script automatically creates history.db on the first run.



&nbsp;   Start the Server:

&nbsp;   Bash



&nbsp;   python main.py



&nbsp;   Access the Dashboard: Open your web browser and navigate to:

&nbsp;   http://127.0.0.1:5000



📂 Project Structure



&nbsp;   main.py: The core Flask application and routing logic.



&nbsp;   api\_handler.py: Manages REST API communication with the hardware.



&nbsp;   db\_handler.py: Handles SQLite storage and historical data retrieval.



&nbsp;   utils.py: Helper functions for data formatting.



&nbsp;   static/: Contains the CSS (styles) and JS (dashboard logic).



&nbsp;   templates/: HTML structures and UI components.



💡 Pro Tip



If you make changes to the CSS or JavaScript, remember to use Ctrl + F5 in your browser to perform a hard reload and see the latest updates immediately.



Hoppas denna README lyfter projektet! Vill du att jag lägger till något mer specifikt, till exempel en sektion om felsökning (Troubleshooting)?

